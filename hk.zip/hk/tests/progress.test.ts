import {describe,it,expect} from 'vitest';
import {calculateProgress} from '../src/lib/progress';
describe('calculateProgress',()=>{it('uses weighted completed tasks',()=>{expect(calculateProgress([{status:'DONE',weight:2},{status:'TODO',weight:1}])).toBe(67)});it('combines milestone weights',()=>{expect(calculateProgress([{status:'DONE',weight:1}],[{completed:false,weight:1}])).toBe(50)});it('returns zero for empty work',()=>{expect(calculateProgress([])).toBe(0)})});
