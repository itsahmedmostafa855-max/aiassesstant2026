import {describe,it,expect} from 'vitest';
import {classifyIdea} from '../src/lib/ai';
describe('idea fallback classification',()=>{it('returns validated structured data',async()=>{const result=await classifyIdea('أريد بناء AI bot للعملاء');expect(result.decision).toBe('LATER');expect(result.category).toBe('AI & Automation');expect(result.tags.length).toBeGreaterThan(0)})});
