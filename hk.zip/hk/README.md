# مركز القيادة الشخصي

واجهة عربية RTL لنظام شخصي يساعدك على التقاط الأفكار وتحويلها إلى تنفيذ.

## التشغيل

1. انسخ `.env.example` إلى `.env` وعدّل `AUTH_SECRET`.
2. شغّل PostgreSQL: `docker compose up -d db`.
3. ثبّت الحزم: `npm install`.
4. أنشئ قاعدة البيانات: `npx prisma migrate dev --name init` ثم `npm run prisma:seed`.
5. شغّل التطبيق: `npm run dev` وافتح `http://localhost:3000`.

المسار الحالي يقدّم أساس Phase 1: لوحة عربية RTL، Inbox لالتقاط الأفكار، fallback AI آمن، مشاريع، وتركيز اليوم. ربط مزوّد AI خارجي، المصادقة الكاملة، وعمليات CRUD المتصلة بقاعدة البيانات هي الخطوات التالية قبل الإطلاق.
