import { z } from 'zod';
export const ideaAnalysisSchema = z.object({ title:z.string().min(1), description:z.string(), category:z.string(), tags:z.array(z.string()), difficulty:z.enum(['سهل','متوسط','صعب']), effortHours:z.number().nonnegative(), alignmentScore:z.number().int().min(0).max(100), decision:z.enum(['KEEP','LATER','DROP']), reason:z.string(), nextAction:z.string() });
export type IdeaAnalysis = z.infer<typeof ideaAnalysisSchema>;
export async function classifyIdea(originalText:string):Promise<IdeaAnalysis>{
  // Deterministic fallback keeps capture usable without an AI key. A provider adapter can replace this implementation.
  const lower=originalText.toLowerCase(); const category=lower.includes('ai')||lower.includes('automation')?'AI & Automation':lower.includes('learn')?'Learning & Skills':'Future Opportunities';
  const analysis={title:originalText.trim().slice(0,60)||'فكرة جديدة',description:'فكرة تحتاج إلى تحويلها إلى خطوة عملية صغيرة.',category,tags:['مراجعة'],difficulty:'متوسط' as const,effortHours:4,alignmentScore:60,decision:'LATER' as const,reason:'مبدئياً نحتاج تفاصيل أكثر قبل الالتزام.',nextAction:'اكتب أول نتيجة قابلة للتسليم خلال 30 دقيقة.'};
  return ideaAnalysisSchema.parse(analysis);
}
