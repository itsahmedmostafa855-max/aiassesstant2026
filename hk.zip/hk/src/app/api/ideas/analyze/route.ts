import {NextResponse} from 'next/server'; import {z} from 'zod'; import {classifyIdea} from '@/lib/ai';
const body=z.object({text:z.string().min(3).max(5000)});
export async function POST(req:Request){try{const data=body.parse(await req.json()); return NextResponse.json(await classifyIdea(data.text));}catch(e){return NextResponse.json({error:'تعذر تحليل الفكرة، حاول مرة أخرى.'},{status:400});}}
